# Discord Moderation

---

## Features
- Create a Profile.
- List your Skills as a Mod
- Look for Job Oppertunities with other Server Owners

---

## Credits
- Head Developers: 
Real Toxic Dev,
Dillon

- Idea:
Vagabond.it

- Design:
GamerCreator1
