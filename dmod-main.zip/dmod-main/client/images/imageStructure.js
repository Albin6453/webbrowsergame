exports.dmodv2 = 'https://cdn.discordapp.com/attachments/756076154217168937/791768591514468372/dmodv2.png'
exports.dmod_transparent = 'https://cdn.discordapp.com/attachments/756076154217168937/791768610674442260/transparent_dmod.png'
exports.mainColor = '#181944'
